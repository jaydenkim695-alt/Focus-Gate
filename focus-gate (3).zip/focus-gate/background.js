importScripts("defaults.js");

// Rebuilds run one at a time, so overlapping triggers (install, startup,
// settings changes) can never add the same rule id twice.
let syncQueue = Promise.resolve();
function syncRules() {
  syncQueue = syncQueue.then(doSync).catch((e) => console.error("Focus Gate sync failed:", e));
  return syncQueue;
}

// Rebuilds all redirect rules from the saved settings.
async function doSync() {
  const settings = await getSettings();
  const existing = await chrome.declarativeNetRequest.getDynamicRules();
  const removeRuleIds = existing.map((r) => r.id);
  const addRules = [];
  const usedIds = new Set();

  if (settings.enabled) {
    for (const entry of getEntries(settings)) {
      if (!entry.enabled || usedIds.has(entry.id)) continue;
      usedIds.add(entry.id);
      const regex = buildRegex(entry.patterns);
      const { isSupported } = await chrome.declarativeNetRequest.isRegexSupported({ regex });
      if (!isSupported) continue;

      addRules.push({
        id: entry.id,
        priority: 1,
        action: {
          type: "redirect",
          redirect: {
            url: chrome.runtime.getURL(`blocked.html?name=${encodeURIComponent(entry.name)}`),
          },
        },
        condition: {
          regexFilter: regex,
          isUrlFilterCaseSensitive: false,
          resourceTypes: ["main_frame"],
        },
      });
    }
  }

  await chrome.declarativeNetRequest.updateDynamicRules({ removeRuleIds, addRules });
}

chrome.runtime.onInstalled.addListener(async () => {
  const { settings } = await chrome.storage.local.get("settings");
  if (!settings) await saveSettings(DEFAULT_SETTINGS);
  syncRules();
});

chrome.runtime.onStartup.addListener(syncRules);

chrome.storage.onChanged.addListener((changes, area) => {
  if (area === "local" && changes.settings) syncRules();
});
