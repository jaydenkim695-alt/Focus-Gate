// Block list tab: search, categories, add-your-own.
(() => {
  const $ = (id) => document.getElementById(id);

  let settings;
  let query = "";
  let cat = "All";

  function el(tag, cls, text) {
    const e = document.createElement(tag);
    if (cls) e.className = cls;
    if (text !== undefined) e.textContent = text;
    return e;
  }

  function visibleEntries() {
    const q = query.trim().toLowerCase();
    return getEntries(settings).filter((e) => {
      if (cat === "Blocked" && !e.enabled) return false;
      if (cat !== "All" && cat !== "Blocked" && e.category !== cat) return false;
      if (!q) return true;
      return e.name.toLowerCase().includes(q) || e.patterns.some((p) => p.includes(q));
    });
  }

  function renderPills() {
    const box = $("pills");
    box.innerHTML = "";
    const hasCustom = (settings.custom || []).length > 0;
    const names = ["All", "Blocked", ...(hasCustom ? ["Custom"] : []), ...CATEGORIES];
    if (!names.includes(cat)) cat = "All";
    for (const n of names) {
      const b = el("button", "pill-btn" + (n === cat ? " sel" : ""), n);
      b.addEventListener("click", () => { cat = n; render(); });
      box.appendChild(b);
    }
  }

  async function setEntries(entries, on) {
    settings = await updateSettings((s) => {
      for (const e of entries) {
        if (e.custom) {
          const c = s.custom.find((x) => x.id === e.id);
          if (c) c.enabled = on;
        } else {
          s.sites[e.key] = on;
        }
      }
    });
    render();
  }

  function renderGroups() {
    const box = $("groups");
    box.innerHTML = "";
    const entries = visibleEntries();

    if (!entries.length) {
      box.appendChild(el("div", "empty-state", query
        ? "No matches. Type the full address in “Add any website” above to block it."
        : "Nothing here yet."));
      return;
    }

    for (const g of ["Custom", ...CATEGORIES]) {
      const items = entries.filter((e) => e.category === g);
      if (!items.length) continue;

      const group = el("div", "group");
      group.appendChild(el("h2", "", g));
      const grid = el("div", "site-grid");

      for (const e of items) {
        const card = el("div", "site-card" + (e.enabled ? " on" : ""));

        const a = avatar(e.name);
        const av = el("div", "av", a.ch);
        av.style.background = a.bg;

        const meta = el("div", "meta");
        meta.append(el("div", "nm", e.name), el("div", "dm", e.patterns.join(", ")));

        card.append(av, meta);

        if (e.custom) {
          const rm = el("button", "rm", "×");
          rm.title = "Remove from list";
          rm.addEventListener("click", async () => {
            settings = await updateSettings((s) => {
              s.custom = s.custom.filter((x) => x.id !== e.id);
            });
            render();
          });
          card.appendChild(rm);
        }

        const sw = el("label", "switch");
        sw.innerHTML = '<input type="checkbox" /><span class="track"></span><span class="thumb"></span>';
        const input = sw.querySelector("input");
        input.checked = e.enabled;
        input.addEventListener("change", () => {
          card.classList.toggle("on", input.checked);
          setEntries([e], input.checked);
        });
        card.appendChild(sw);

        grid.appendChild(card);
      }

      group.appendChild(grid);
      box.appendChild(group);
    }
  }

  function render() {
    const n = getEntries(settings).filter((e) => e.enabled).length;
    $("stat").innerHTML = `<b>${n}</b> site${n === 1 ? "" : "s"} blocked`;
    $("search").placeholder = `Search ${CATALOG.length}+ sites`;
    renderPills();
    renderGroups();
  }

  function note(text, isErr) {
    const m = $("addMsg");
    m.textContent = text;
    m.classList.toggle("err", !!isErr);
    clearTimeout(note.t);
    note.t = setTimeout(() => (m.textContent = ""), 6000);
  }

  async function addSites() {
    const { valid, invalid } = parseMany($("addInput").value);
    if (!valid.length) {
      note(invalid.length ? `That doesn't look like a website: ${invalid.join(", ")}` : "Type a website first.", true);
      return;
    }

    let added = 0;
    settings = await updateSettings((s) => {
      for (const p of valid) {
        const known = CATALOG.find((c) => c.patterns.includes(p));
        if (known) { s.sites[known.key] = true; added++; continue; }
        const dupe = s.custom.find((c) => c.pattern === p);
        if (dupe) { dupe.enabled = true; added++; continue; }
        s.custom.push({ id: nextCustomId(s), pattern: p, enabled: true });
        added++;
      }
    });

    $("addInput").value = "";
    let msg = `Blocked ${added} site${added === 1 ? "" : "s"}.`;
    if (invalid.length) msg += ` Couldn't read: ${invalid.join(", ")}`;
    note(msg, invalid.length > 0 && added === 0);
    render();
  }

  $("addBtn").addEventListener("click", addSites);
  $("addInput").addEventListener("keydown", (e) => { if (e.key === "Enter") addSites(); });
  $("search").addEventListener("input", (e) => { query = e.target.value; renderGroups(); });
  $("blockShown").addEventListener("click", () => setEntries(visibleEntries(), true));
  $("unblockShown").addEventListener("click", () => setEntries(visibleEntries(), false));

  // Keep in sync with changes made from the popup
  chrome.storage.onChanged.addListener(async (changes, area) => {
    if (area === "local" && changes.settings) {
      settings = await getSettings();
      render();
    }
  });

  getSettings().then((s) => { settings = s; render(); });
})();
