// Tabs + Block screen editor.
const $ = (id) => document.getElementById(id);

const MAX_MEDIA = 12;
const MAX_MB = 100;
const ACCENTS = ["#8ab4f8", "#c58af9", "#81c995", "#fde293", "#f28b82", "#ffffff"];
const TEXT_COLORS = ["gradient", "#ffffff", "#000000", "#fde293", "#f28b82", "#81c995", "#8ab4f8"];

let settings;
let saveTimer;
let thumbToken = 0;
const thumbUrls = [];

/* ---------- Tabs ---------- */
function showTab(name) {
  document.querySelectorAll(".tab").forEach((t) => t.classList.toggle("hidden", t.id !== "tab-" + name));
  document.querySelectorAll("[data-tab]").forEach((b) => b.classList.toggle("sel", b.dataset.tab === name));
  fitPreview();
}
function tabFromHash() {
  return location.hash === "#screen" ? "screen" : "blocklist";
}
document.querySelectorAll("[data-tab]").forEach((b) =>
  b.addEventListener("click", () => { location.hash = b.dataset.tab; })
);
window.addEventListener("hashchange", () => showTab(tabFromHash()));

/* ---------- Preview scaling (iframe is a real 1440x900 screen) ---------- */
function fitPreview() {
  const frame = $("frame");
  const w = frame.clientWidth;
  if (w) $("preview").style.transform = `scale(${w / 1440})`;
}
new ResizeObserver(fitPreview).observe($("frame"));

/* ---------- Saving ---------- */
function save() {
  clearTimeout(saveTimer);
  saveTimer = setTimeout(() => updateSettings((s) => { s.screen = settings.screen; }), 120);
}

/* ---------- Media ---------- */
function note(text, isErr = true) {
  const n = $("upNote");
  n.textContent = text;
  n.classList.toggle("err", isErr);
  clearTimeout(note.t);
  note.t = setTimeout(() => (n.textContent = ""), 6000);
}

async function renderThumbs() {
  const token = ++thumbToken;
  thumbUrls.splice(0).forEach((u) => URL.revokeObjectURL(u));
  const box = $("thumbs");
  box.innerHTML = "";

  for (const m of settings.screen.media) {
    const blob = await getMedia(m.id);
    if (token !== thumbToken) return;
    if (!blob) continue;

    const url = URL.createObjectURL(blob);
    thumbUrls.push(url);

    const d = document.createElement("div");
    d.className = "thumb-item";
    d.title = m.name || "";

    if (m.type === "video") {
      const v = document.createElement("video");
      v.src = url + "#t=0.1";
      v.muted = true;
      v.preload = "metadata";
      v.playsInline = true;
      d.appendChild(v);
    } else {
      const img = document.createElement("img");
      img.src = url;
      d.appendChild(img);
    }

    if (m.type !== "image") {
      const tag = document.createElement("span");
      tag.className = "tag";
      tag.textContent = m.type === "gif" ? "GIF" : "VIDEO";
      d.appendChild(tag);
    }

    const x = document.createElement("button");
    x.textContent = "×";
    x.title = "Remove";
    x.addEventListener("click", async (ev) => {
      ev.stopPropagation();
      await deleteMedia(m.id);
      settings.screen.media = settings.screen.media.filter((i) => i.id !== m.id);
      renderThumbs();
      save();
    });
    d.appendChild(x);

    d.addEventListener("click", () => chrome.storage.local.set({ previewMedia: m.id }));
    box.appendChild(d);
  }
}

// Shrinks big photos so they stay light; GIFs and videos are stored untouched.
async function compress(file) {
  const bmp = await createImageBitmap(file);
  const scale = Math.min(1, 1920 / Math.max(bmp.width, bmp.height));
  const c = document.createElement("canvas");
  c.width = Math.round(bmp.width * scale);
  c.height = Math.round(bmp.height * scale);
  c.getContext("2d").drawImage(bmp, 0, 0, c.width, c.height);
  return new Promise((res, rej) => c.toBlob((b) => (b ? res(b) : rej()), "image/jpeg", 0.85));
}

async function addFiles(files) {
  for (const f of files) {
    if (settings.screen.media.length >= MAX_MEDIA) { note(`You can keep up to ${MAX_MEDIA} files.`); break; }

    const isVideo = f.type.startsWith("video/");
    const isImage = f.type.startsWith("image/");
    if (!isVideo && !isImage) { note(`${f.name} isn't an image or video.`); continue; }
    if (f.size > MAX_MB * 1024 * 1024) { note(`${f.name} is over ${MAX_MB} MB.`); continue; }

    const type = isVideo ? "video" : f.type === "image/gif" ? "gif" : "image";
    let blob = f;
    if (type === "image") { try { blob = await compress(f); } catch { blob = f; } }

    const id = crypto.randomUUID();
    await putMedia(id, blob);
    settings.screen.media.push({ id, type, name: f.name });
  }
  renderThumbs();
  save();
}

// v1.0 stored photos as data URLs in settings. Move them into the new media store.
async function migratePhotos() {
  const legacy = settings.screen.photos || [];
  if (!legacy.length) return;
  for (const dataUrl of legacy) {
    try {
      const blob = await (await fetch(dataUrl)).blob();
      const id = crypto.randomUUID();
      await putMedia(id, blob);
      settings.screen.media.push({ id, type: "image", name: "photo" });
    } catch {}
  }
  settings.screen.photos = [];
  await updateSettings((s) => { s.screen = settings.screen; });
}

/* ---------- Swatches & controls ---------- */
function renderSwatches() {
  const accent = $("colors");
  accent.innerHTML = "";
  ACCENTS.forEach((c) => {
    const b = document.createElement("button");
    b.className = "swatch" + (settings.screen.accent === c ? " sel" : "");
    b.style.background = c;
    b.title = c;
    b.addEventListener("click", () => { settings.screen.accent = c; renderSwatches(); save(); });
    accent.appendChild(b);
  });

  const text = $("textColors");
  text.innerHTML = "";
  TEXT_COLORS.forEach((c) => {
    const b = document.createElement("button");
    b.className = "swatch" + (settings.screen.textColor === c ? " sel" : "");
    b.style.background = c === "gradient"
      ? `linear-gradient(135deg,#fff,${settings.screen.accent})`
      : c;
    b.title = c === "gradient" ? "Gradient" : c;
    b.addEventListener("click", () => { settings.screen.textColor = c; renderSwatches(); save(); });
    text.appendChild(b);
  });
}

function renderWeight() {
  document.querySelectorAll("#weight button").forEach((b) =>
    b.classList.toggle("sel", +b.dataset.v === settings.screen.weight)
  );
}

function fillForm() {
  const s = settings.screen;
  $("title").value = s.title;
  $("message").value = s.message;
  $("overlay").value = s.overlay;
  $("blur").value = s.blur;
  $("overlayOut").textContent = s.overlay + "%";
  $("blurOut").textContent = s.blur + "px";
  $("font").value = s.fontId;
  $("customFont").value = s.customFont;
  $("headlineSize").value = s.headlineSize;
  $("messageSize").value = s.messageSize;
  $("hsOut").textContent = s.headlineSize + "px";
  $("msOut").textContent = s.messageSize + "px";
  $("showSite").checked = s.showSite;
  $("showClock").checked = s.showClock;
  renderWeight();
  renderSwatches();
  renderThumbs();
}

/* ---------- Wiring ---------- */
FONTS.forEach((f) => {
  const o = document.createElement("option");
  o.value = f.id;
  o.textContent = f.label;
  $("font").appendChild(o);
});

function bindRange(id, outId, unit, key) {
  $(id).addEventListener("input", (e) => {
    settings.screen[key] = +e.target.value;
    $(outId).textContent = e.target.value + unit;
    save();
  });
}

$("title").addEventListener("input", (e) => { settings.screen.title = e.target.value; save(); });
$("message").addEventListener("input", (e) => { settings.screen.message = e.target.value; save(); });
bindRange("overlay", "overlayOut", "%", "overlay");
bindRange("blur", "blurOut", "px", "blur");
bindRange("headlineSize", "hsOut", "px", "headlineSize");
bindRange("messageSize", "msOut", "px", "messageSize");

$("font").addEventListener("change", (e) => {
  settings.screen.fontId = e.target.value;
  settings.screen.customFont = "";
  $("customFont").value = "";
  save();
});
$("customFont").addEventListener("input", (e) => { settings.screen.customFont = e.target.value; save(); });

document.querySelectorAll("#weight button").forEach((b) =>
  b.addEventListener("click", () => { settings.screen.weight = +b.dataset.v; renderWeight(); save(); })
);

$("showSite").addEventListener("change", (e) => { settings.screen.showSite = e.target.checked; save(); });
$("showClock").addEventListener("change", (e) => { settings.screen.showClock = e.target.checked; save(); });

const drop = $("drop");
drop.addEventListener("click", () => $("file").click());
$("file").addEventListener("change", (e) => { addFiles([...e.target.files]); e.target.value = ""; });
["dragenter", "dragover"].forEach((ev) =>
  drop.addEventListener(ev, (e) => { e.preventDefault(); drop.classList.add("over"); })
);
["dragleave", "drop"].forEach((ev) =>
  drop.addEventListener(ev, (e) => { e.preventDefault(); drop.classList.remove("over"); })
);
drop.addEventListener("drop", (e) => addFiles([...e.dataTransfer.files]));

$("reset").addEventListener("click", async () => {
  for (const m of settings.screen.media) await deleteMedia(m.id);
  settings.screen = JSON.parse(JSON.stringify(DEFAULT_SETTINGS.screen));
  chrome.storage.local.remove("previewMedia");
  fillForm();
  save();
});

(async function init() {
  settings = await getSettings();
  await migratePhotos();
  fillForm();
  showTab(tabFromHash());
})();
