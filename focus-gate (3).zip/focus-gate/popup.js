const list = document.getElementById("list");
const master = document.getElementById("master");
const statusEl = document.getElementById("status");
const here = document.getElementById("here");

let settings;
let tab = null;
let shown = new Set(); // keys visible in the list (so a row stays put after you switch it off)

function matches(entry, url) {
  return new RegExp(buildRegex(entry.patterns), "i").test(url);
}

function setAvatar(el, name) {
  const a = avatar(name);
  el.textContent = a.ch;
  el.style.background = a.bg;
}

function render() {
  const entries = getEntries(settings);
  const active = entries.filter((e) => e.enabled);

  master.checked = settings.enabled;
  list.classList.toggle("off", !settings.enabled);
  statusEl.textContent = settings.enabled
    ? `Blocking ${active.length} site${active.length === 1 ? "" : "s"}`
    : "Paused";

  renderHere(entries);

  list.innerHTML = "";
  const rows = entries
    .filter((e) => e.enabled || shown.has(e.key))
    .sort((a, b) => a.name.localeCompare(b.name));

  if (!rows.length) {
    const d = document.createElement("div");
    d.className = "empty";
    d.textContent = "Nothing blocked yet. Open “Manage block list” to add sites.";
    list.appendChild(d);
    return;
  }

  for (const e of rows) {
    const row = document.createElement("div");
    row.className = "row";

    const av = document.createElement("div");
    av.className = "av";
    setAvatar(av, e.name);

    const g = document.createElement("div");
    g.className = "grow";
    const nm = document.createElement("div");
    nm.className = "name";
    nm.textContent = e.name;
    const hn = document.createElement("div");
    hn.className = "hint";
    hn.textContent = e.patterns[0];
    g.append(nm, hn);

    const sw = document.createElement("label");
    sw.className = "switch";
    sw.innerHTML = '<input type="checkbox" /><span class="track"></span><span class="thumb"></span>';
    const input = sw.querySelector("input");
    input.checked = e.enabled;
    input.addEventListener("change", async () => {
      await setEntry(e, input.checked);
    });

    row.append(av, g, sw);
    list.appendChild(row);
  }
}

function renderHere(entries) {
  if (!tab) { here.classList.add("hidden"); return; }
  let host;
  try { host = new URL(tab.url).hostname.replace(/^www\./, ""); } catch { return; }

  const blockedBy = entries.filter((e) => e.enabled && matches(e, tab.url));
  here.classList.remove("hidden");
  setAvatar(document.getElementById("hereAv"), host);
  document.getElementById("hereName").textContent = host;
  document.getElementById("hereState").textContent = blockedBy.length ? "Blocked" : "This tab";

  const btn = document.getElementById("hereBtn");
  btn.textContent = blockedBy.length ? "Unblock" : "Block";
  btn.classList.toggle("off", blockedBy.length > 0);
}

async function setEntry(entry, on) {
  settings = await updateSettings((s) => {
    if (entry.custom) {
      const c = s.custom.find((x) => x.id === entry.id);
      if (c) c.enabled = on;
    } else {
      s.sites[entry.key] = on;
    }
  });
  if (on) shown.add(entry.key);
  render();
}

document.getElementById("hereBtn").addEventListener("click", async () => {
  if (!tab) return;
  const host = new URL(tab.url).hostname.replace(/^www\./, "");
  const entries = getEntries(settings);
  const blockedBy = entries.filter((e) => e.enabled && matches(e, tab.url));

  if (blockedBy.length) {
    settings = await updateSettings((s) => {
      for (const e of blockedBy) {
        if (e.custom) { const c = s.custom.find((x) => x.id === e.id); if (c) c.enabled = false; }
        else s.sites[e.key] = false;
      }
    });
  } else {
    const known = entries.find((e) => !e.enabled && matches(e, tab.url));
    settings = await updateSettings((s) => {
      if (known && !known.custom) {
        s.sites[known.key] = true;
      } else if (known && known.custom) {
        const c = s.custom.find((x) => x.id === known.id);
        if (c) c.enabled = true;
      } else {
        s.custom.push({ id: nextCustomId(s), pattern: host, enabled: true });
      }
    });
    const now = getEntries(settings).find((e) => e.enabled && matches(e, tab.url));
    if (now) shown.add(now.key);
  }

  render();
  // give the background worker a moment to rebuild the rules, then reload the tab
  setTimeout(() => chrome.tabs.reload(tab.id), 350);
});

master.addEventListener("change", async () => {
  settings = await updateSettings((s) => { s.enabled = master.checked; });
  render();
});

function openOptions(hash) {
  chrome.tabs.create({ url: chrome.runtime.getURL("options.html#" + hash) });
  window.close();
}
document.getElementById("manage").addEventListener("click", () => openOptions("blocklist"));
document.getElementById("customize").addEventListener("click", () => openOptions("screen"));

(async function init() {
  settings = await getSettings();
  shown = new Set(getEntries(settings).filter((e) => e.enabled).map((e) => e.key));
  try {
    const [t] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (t && /^https?:\/\//.test(t.url || "")) tab = t;
  } catch {}
  render();
})();
