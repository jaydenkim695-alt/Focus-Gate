// Shared by the background worker, popup, options page and block screen.

const CATEGORIES = [
  "Social", "Video & streaming", "Gaming", "Shopping",
  "News & forums", "Sports", "Messaging", "Music", "Search & AI",
];

// [key, display name, "pattern,pattern"]  (a pattern is domain or domain/path)
const CATALOG_DATA = {
  "Social": [
    ["instagram", "Instagram", "instagram.com"],
    ["facebook", "Facebook", "facebook.com,fb.com"],
    ["x", "X (Twitter)", "x.com,twitter.com"],
    ["tiktok", "TikTok", "tiktok.com"],
    ["snapchat", "Snapchat", "snapchat.com"],
    ["reddit", "Reddit", "reddit.com,redd.it"],
    ["pinterest", "Pinterest", "pinterest.com"],
    ["tumblr", "Tumblr", "tumblr.com"],
    ["linkedin", "LinkedIn", "linkedin.com"],
    ["threads", "Threads", "threads.net,threads.com"],
    ["bluesky", "Bluesky", "bsky.app"],
  ],
  "Video & streaming": [
    ["youtube", "YouTube", "youtube.com,youtu.be"],
    ["netflix", "Netflix", "netflix.com"],
    ["twitch", "Twitch", "twitch.tv"],
    ["hulu", "Hulu", "hulu.com"],
    ["disney-plus", "Disney+", "disneyplus.com"],
    ["prime-video", "Prime Video", "primevideo.com"],
    ["max", "Max", "max.com,hbomax.com"],
    ["peacock", "Peacock", "peacocktv.com"],
    ["paramount-plus", "Paramount+", "paramountplus.com"],
    ["vimeo", "Vimeo", "vimeo.com"],
    ["dailymotion", "Dailymotion", "dailymotion.com"],
    ["crunchyroll", "Crunchyroll", "crunchyroll.com"],
    ["tubi", "Tubi", "tubitv.com"],
    ["apple-tv", "Apple TV+", "tv.apple.com"],
  ],
  "Gaming": [
    ["roblox", "Roblox", "roblox.com"],
    ["steam", "Steam", "steampowered.com,steamcommunity.com"],
    ["epic-games", "Epic Games", "epicgames.com"],
    ["fortnite", "Fortnite", "fortnite.com"],
    ["minecraft", "Minecraft", "minecraft.net"],
    ["poki", "Poki", "poki.com"],
    ["crazygames", "CrazyGames", "crazygames.com"],
    ["y8", "Y8", "y8.com"],
    ["miniclip", "Miniclip", "miniclip.com"],
    ["itch", "itch.io", "itch.io"],
    ["chess", "Chess.com", "chess.com"],
    ["lichess", "Lichess", "lichess.org"],
    ["kongregate", "Kongregate", "kongregate.com"],
    ["coolmath", "Coolmath Games", "coolmathgames.com"],
    ["friv", "Friv", "friv.com"],
    ["xbox", "Xbox", "xbox.com"],
    ["playstation", "PlayStation", "playstation.com"],
    ["riot", "Riot Games", "riotgames.com"],
    ["battlenet", "Battle.net", "battle.net"],
    ["geoguessr", "GeoGuessr", "geoguessr.com"],
  ],
  "Shopping": [
    ["amazon", "Amazon", "amazon.com"],
    ["ebay", "eBay", "ebay.com"],
    ["etsy", "Etsy", "etsy.com"],
    ["temu", "Temu", "temu.com"],
    ["shein", "SHEIN", "shein.com"],
    ["aliexpress", "AliExpress", "aliexpress.com"],
    ["walmart", "Walmart", "walmart.com"],
    ["target", "Target", "target.com"],
    ["bestbuy", "Best Buy", "bestbuy.com"],
    ["depop", "Depop", "depop.com"],
    ["nike", "Nike", "nike.com"],
  ],
  "News & forums": [
    ["quora", "Quora", "quora.com"],
    ["9gag", "9GAG", "9gag.com"],
    ["imgur", "Imgur", "imgur.com"],
    ["hacker-news", "Hacker News", "news.ycombinator.com"],
    ["buzzfeed", "BuzzFeed", "buzzfeed.com"],
    ["cnn", "CNN", "cnn.com"],
    ["fox-news", "Fox News", "foxnews.com"],
    ["nyt", "New York Times", "nytimes.com"],
    ["bbc", "BBC", "bbc.com,bbc.co.uk"],
    ["medium", "Medium", "medium.com"],
    ["tmz", "TMZ", "tmz.com"],
    ["know-your-meme", "Know Your Meme", "knowyourmeme.com"],
    ["ifunny", "iFunny", "ifunny.co"],
  ],
  "Sports": [
    ["espn", "ESPN", "espn.com"],
    ["nba", "NBA", "nba.com"],
    ["nfl", "NFL", "nfl.com"],
    ["mlb", "MLB", "mlb.com"],
    ["nhl", "NHL", "nhl.com"],
    ["bleacher-report", "Bleacher Report", "bleacherreport.com"],
  ],
  "Messaging": [
    ["discord", "Discord", "discord.com,discordapp.com,discord.gg"],
    ["whatsapp", "WhatsApp", "whatsapp.com"],
    ["telegram", "Telegram", "telegram.org,t.me"],
    ["messenger", "Messenger", "messenger.com"],
  ],
  "Music": [
    ["spotify", "Spotify", "spotify.com"],
    ["soundcloud", "SoundCloud", "soundcloud.com"],
    ["apple-music", "Apple Music", "music.apple.com"],
    ["pandora", "Pandora", "pandora.com"],
    ["youtube-music", "YouTube Music", "music.youtube.com"],
  ],
  "Search & AI": [
    ["google-search", "Google Search", "google.com/search"],
    ["bing-search", "Bing Search", "bing.com/search"],
    ["duckduckgo", "DuckDuckGo", "duckduckgo.com"],
    ["yahoo-search", "Yahoo Search", "search.yahoo.com"],
    ["chatgpt", "ChatGPT", "chatgpt.com,chat.openai.com"],
    ["gemini", "Gemini", "gemini.google.com"],
    ["perplexity", "Perplexity", "perplexity.ai"],
    ["character-ai", "Character.AI", "character.ai"],
  ],
};

const CATALOG = (() => {
  const out = [];
  let id = 1;
  for (const category of CATEGORIES) {
    for (const [key, name, patterns] of CATALOG_DATA[category]) {
      out.push({ id: id++, key, name, category, patterns: patterns.split(",") });
    }
  }
  return out;
})();

const FONTS = [
  { id: "google-sans", label: "Google Sans style (default)", stack: '"Google Sans","Product Sans",Roboto,"Segoe UI",system-ui,sans-serif' },
  { id: "inter", label: "Inter", family: "Inter", multi: true },
  { id: "poppins", label: "Poppins", family: "Poppins", multi: true },
  { id: "montserrat", label: "Montserrat", family: "Montserrat", multi: true },
  { id: "space-grotesk", label: "Space Grotesk", family: "Space Grotesk", multi: true },
  { id: "orbitron", label: "Orbitron (futuristic)", family: "Orbitron", multi: true },
  { id: "oswald", label: "Oswald (tall)", family: "Oswald", multi: true },
  { id: "bebas", label: "Bebas Neue (poster)", family: "Bebas Neue" },
  { id: "playfair", label: "Playfair Display (elegant)", family: "Playfair Display", multi: true },
  { id: "georgia", label: "Georgia (classic serif)", stack: 'Georgia,"Times New Roman",serif' },
  { id: "pacifico", label: "Pacifico (script)", family: "Pacifico" },
  { id: "caveat", label: "Caveat (handwritten)", family: "Caveat", multi: true },
  { id: "righteous", label: "Righteous (rounded display)", family: "Righteous" },
  { id: "press-start", label: "Press Start 2P (pixel)", family: "Press Start 2P" },
  { id: "jetbrains", label: "JetBrains Mono", family: "JetBrains Mono", multi: true },
  { id: "mono", label: "Monospace (system)", stack: 'ui-monospace,"SF Mono",Menlo,Consolas,monospace' },
];

// Returns the CSS font stack plus a Google Fonts stylesheet URL (or null).
function fontInfo(screen) {
  const custom = (screen.customFont || "").trim();
  let family = null, multi = false, stack = null;

  if (/^[A-Za-z0-9 ]{2,40}$/.test(custom)) {
    family = custom;
  } else {
    const f = FONTS.find((x) => x.id === screen.fontId) || FONTS[0];
    if (f.stack) stack = f.stack;
    else { family = f.family; multi = !!f.multi; }
  }

  if (stack) return { stack, href: null };
  const fam = encodeURIComponent(family).replace(/%20/g, "+");
  const href = `https://fonts.googleapis.com/css2?family=${fam}${multi ? ":wght@400;500;700" : ""}&display=swap`;
  return { stack: `"${family}",system-ui,sans-serif`, href };
}

const DEFAULT_SETTINGS = {
  enabled: true,
  sites: { "google-search": true, reddit: true, youtube: true, instagram: true },
  custom: [], // [{ id, pattern, enabled }]
  screen: {
    title: "Not right now.",
    message: "Future you will thank you. Get back to it.",
    accent: "#8ab4f8",
    overlay: 45,        // 0-90  (% dark overlay on media)
    blur: 0,            // 0-20  (px blur on media)
    showSite: true,
    showClock: true,
    media: [],          // [{ id, type: "image" | "gif" | "video", name }] (files live in IndexedDB)
    photos: [],         // legacy (v1.0) data URLs, migrated by the options page
    fontId: "google-sans",
    customFont: "",
    headlineSize: 88,   // px
    messageSize: 20,    // px
    weight: 500,
    textColor: "gradient",
  },
};

async function getSettings() {
  const { settings } = await chrome.storage.local.get("settings");
  const s = settings || {};
  const sites = { ...DEFAULT_SETTINGS.sites, ...(s.sites || {}) };

  // v1.0 used the key "google" for Google Search
  if (s.sites && s.sites.google !== undefined) {
    sites["google-search"] = !!s.sites.google;
    delete sites.google;
  }

  return {
    ...DEFAULT_SETTINGS,
    ...s,
    sites,
    custom: Array.isArray(s.custom) ? s.custom : [],
    screen: { ...DEFAULT_SETTINGS.screen, ...(s.screen || {}) },
  };
}

async function saveSettings(settings) {
  await chrome.storage.local.set({ settings });
}

// Read-modify-write so different pages never overwrite each other's changes.
async function updateSettings(mutator) {
  const s = await getSettings();
  mutator(s);
  await saveSettings(s);
  return s;
}

/* ---------- Block list helpers ---------- */

function getEntries(settings) {
  const catalog = CATALOG.map((c) => ({
    ...c, custom: false, enabled: !!settings.sites[c.key],
  }));
  const custom = (settings.custom || []).map((c) => ({
    id: c.id, key: "custom-" + c.id, name: c.pattern, category: "Custom",
    patterns: [c.pattern], custom: true, enabled: c.enabled !== false,
  }));
  return [...custom, ...catalog];
}

function nextCustomId(settings) {
  return Math.max(999, ...(settings.custom || []).map((c) => c.id)) + 1;
}

function escapeRe(s) {
  return s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

// Turns ["reddit.com", "youtube.com/shorts"] into one RE2-safe regex.
function buildRegex(patterns) {
  const alts = patterns.map((p) => {
    const i = p.indexOf("/");
    const host = escapeRe(i === -1 ? p : p.slice(0, i));
    const path = i === -1 ? "" : escapeRe(p.slice(i));
    return path ? host + path : host + "(?::[0-9]+)?(?:[/?#]|$)";
  });
  return "^https?://(?:[a-z0-9-]+\\.)*(?:" + alts.join("|") + ")";
}

// "https://www.TikTok.com/foo?x=1" -> "tiktok.com/foo". Returns null if it isn't a website.
function normalizePattern(raw) {
  let s = String(raw || "").trim().toLowerCase();
  if (!s) return null;
  s = s.replace(/^[a-z][a-z0-9+.-]*:\/\//, "");
  s = s.replace(/^www\./, "");
  s = s.split(/[?#]/)[0].replace(/\/+$/, "");
  s = s.replace(/^([^\/]+?):[0-9]+/, "$1");
  if (!/^[a-z0-9-]+(\.[a-z0-9-]+)+(\/[^\s]*)?$/.test(s)) return null;
  return s;
}

function parseMany(text) {
  const valid = [], invalid = [];
  for (const piece of String(text).split(/[\s,;]+/).filter(Boolean)) {
    const p = normalizePattern(piece);
    if (p) { if (!valid.includes(p)) valid.push(p); } else invalid.push(piece);
  }
  return { valid, invalid };
}

/* ---------- Small UI helpers ---------- */

function avatar(name) {
  const ch = (name.replace(/[^a-z0-9]/gi, "")[0] || "?").toUpperCase();
  let h = 0;
  for (const c of name) h = (h * 31 + c.charCodeAt(0)) % 360;
  return {
    ch,
    bg: `linear-gradient(135deg,hsl(${h} 70% 55%),hsl(${(h + 45) % 360} 70% 45%))`,
  };
}
