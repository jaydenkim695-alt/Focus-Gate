// Stores uploaded photos / GIFs / videos as Blobs in IndexedDB (too big for storage.local).
// Extension pages share one origin, so the options page and block screen see the same data.

function mediaDB() {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open("focusgate", 1);
    req.onupgradeneeded = () => req.result.createObjectStore("media");
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

async function putMedia(id, blob) {
  const db = await mediaDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction("media", "readwrite");
    tx.objectStore("media").put(blob, id);
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
}

async function getMedia(id) {
  const db = await mediaDB();
  return new Promise((resolve, reject) => {
    const req = db.transaction("media").objectStore("media").get(id);
    req.onsuccess = () => resolve(req.result || null);
    req.onerror = () => reject(req.error);
  });
}

async function deleteMedia(id) {
  const db = await mediaDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction("media", "readwrite");
    tx.objectStore("media").delete(id);
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
}
