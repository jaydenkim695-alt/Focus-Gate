const params = new URLSearchParams(location.search);
const siteName = params.get("name") || "This site";
const isPreview = params.get("preview") === "1";

const $ = (id) => document.getElementById(id);

let currentId = null;   // media item shown right now (stays the same while the page is open)
let loadedId = null;    // media item whose blob URL is loaded
let loadedUrl = null;
let lastCount = 0;
let forced = null;      // preview only: item picked in the editor
let fontLink = null;

function applyFont(screen) {
  const { stack, href } = fontInfo(screen);
  document.documentElement.style.setProperty("--font", stack);
  if (href) {
    if (!fontLink) {
      fontLink = document.createElement("link");
      fontLink.rel = "stylesheet";
      document.head.appendChild(fontLink);
    }
    if (fontLink.href !== href) fontLink.href = href;
  } else if (fontLink) {
    fontLink.remove();
    fontLink = null;
  }
}

function renderClock() {
  $("clock").textContent = new Date().toLocaleTimeString([], { hour: "numeric", minute: "2-digit" });
}

function clearMedia() {
  const bg = $("bg"), vid = $("vid");
  bg.classList.remove("photo");
  bg.style.backgroundImage = "";
  bg.style.filter = "";
  vid.pause();
  vid.removeAttribute("src");
  vid.style.display = "none";
  vid.style.filter = "";
  $("shade").style.opacity = 0;
}

async function renderMedia(screen) {
  const media = screen.media || [];
  let item = null;

  if (isPreview && media.length > lastCount) { item = media[media.length - 1]; forced = null; }
  else if (isPreview && forced) item = media.find((m) => m.id === forced) || null;
  if (!item) item = media.find((m) => m.id === currentId) || null;
  if (!item && media.length) item = media[Math.floor(Math.random() * media.length)];
  lastCount = media.length;
  currentId = item ? item.id : null;

  if (!item) { clearMedia(); return; }

  if (loadedId !== item.id) {
    const blob = await getMedia(item.id);
    if (!blob) { clearMedia(); return; }
    if (loadedUrl) URL.revokeObjectURL(loadedUrl);
    loadedUrl = URL.createObjectURL(blob);
    loadedId = item.id;
  }

  const bg = $("bg"), vid = $("vid");
  bg.classList.add("photo");

  if (item.type === "video") {
    bg.style.backgroundImage = "";
    vid.style.display = "block";
    if (vid.getAttribute("src") !== loadedUrl) {
      vid.src = loadedUrl;
      vid.play().catch(() => {});
    }
  } else {
    vid.pause();
    vid.removeAttribute("src");
    vid.style.display = "none";
    bg.style.backgroundImage = `url("${loadedUrl}")`;
  }

  const blur = `blur(${screen.blur}px)`;
  bg.style.filter = blur;
  vid.style.filter = blur;
  $("shade").style.opacity = screen.overlay / 100;
}

async function render() {
  const { screen } = await getSettings();
  const root = document.documentElement.style;

  root.setProperty("--accent", screen.accent);
  root.setProperty("--hs", screen.headlineSize);
  root.setProperty("--ms", screen.messageSize);
  root.setProperty("--fw", screen.weight);

  const gradient = screen.textColor === "gradient";
  root.setProperty("--tc", gradient ? "#ffffff" : screen.textColor);
  $("title").classList.toggle("gradient", gradient);

  applyFont(screen);

  $("title").textContent = screen.title;
  $("msg").textContent = screen.message;
  $("msg").classList.toggle("hidden", !screen.message.trim());

  $("chip").textContent = `${siteName} is blocked`;
  $("chip").classList.toggle("hidden", !screen.showSite);

  $("clock").classList.toggle("hidden", !screen.showClock);
  renderClock();

  document.title = `${siteName} blocked`;
  await renderMedia(screen);
}

$("vid").addEventListener("error", clearMedia);

render();
setInterval(renderClock, 15000);

// Live updates while customizing
chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== "local") return;
  if (changes.previewMedia && isPreview) forced = changes.previewMedia.newValue || null;
  if (changes.settings || changes.previewMedia) render();
});
